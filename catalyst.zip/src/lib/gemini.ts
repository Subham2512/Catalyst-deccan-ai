const GEMINI_API_KEY = process.env.GEMINI_API_KEY!;
const GEMINI_MODEL = "gemini-2.5-flash";

export async function callGemini(prompt: string): Promise<string> {
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: 0.2,
          maxOutputTokens: 8192,
          responseMimeType: "application/json",
        },
      }),
    }
  );

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Gemini API error: ${res.status} - ${err}`);
  }

  const data = await res.json();
  return data.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
}

export async function callGeminiJSON<T>(prompt: string, retries = 3): Promise<T> {
  let lastError: Error | null = null;

  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const raw = await callGemini(prompt);
      return extractJSON<T>(raw);
    } catch (err) {
      lastError = err as Error;
      console.warn(`JSON parse attempt ${attempt}/${retries} failed:`, (err as Error).message);
      if (attempt < retries) await sleep(500 * attempt);
    }
  }

  throw new Error(`Failed to get valid JSON after ${retries} attempts. Last: ${lastError?.message}`);
}

export function extractJSON<T>(text: string): T {
  try { return JSON.parse(text) as T; } catch { }

  const codeBlock = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (codeBlock) {
    try { return JSON.parse(repairJSON(codeBlock[1].trim())) as T; } catch { }
  }

  const arrayMatch = text.match(/\[[\s\S]*\]/);
  if (arrayMatch) {
    try { return JSON.parse(repairJSON(arrayMatch[0])) as T; } catch { }
  }

  const objectMatch = text.match(/\{[\s\S]*\}/);
  if (objectMatch) {
    try { return JSON.parse(repairJSON(objectMatch[0])) as T; } catch { }
  }

  try { return JSON.parse(aggressiveRepair(text)) as T; } catch { }

  throw new Error("Could not extract valid JSON. Raw: " + text.slice(0, 300));
}

function repairJSON(text: string): string {
  text = text.replace(/,\s*([}\]])/g, "$1");
  text = text.replace(/[\u201C\u201D\u201E]/g, '"');
  text = text.replace(/[\u2018\u2019\u201A]/g, "'");
  text = text.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, "");
  text = text.replace(/"([^"]*?)\n([^"]*?)"/g, (_, a, b) => `"${a} ${b}"`);
  return text;
}

function aggressiveRepair(text: string): string {
  const start = text.search(/[\[{]/);
  if (start === -1) throw new Error("No JSON structure found");
  const openChar = text[start];
  const closeChar = openChar === "[" ? "]" : "}";
  let end = text.lastIndexOf(closeChar);
  if (end === -1) {
    text = text.slice(start).replace(/,\s*$/, "") + closeChar;
    return repairJSON(text);
  }
  return repairJSON(text.slice(start, end + 1));
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}
