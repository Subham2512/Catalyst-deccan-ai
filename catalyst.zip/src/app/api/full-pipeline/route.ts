import { NextRequest } from "next/server";
import { ParsedJD, MatchResult, InterestResult, RankedCandidate, PipelineResult } from "@/types";
import { MOCK_CANDIDATES } from "@/data/candidates";

const BASE_URL = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";

export async function POST(req: NextRequest) {
  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    async start(controller) {
      const send = (data: object) => {
        controller.enqueue(encoder.encode(JSON.stringify(data) + "\n"));
      };

      try {
        const { jdText } = await req.json();

        // Step 1: Parse JD
        send({ step: "parsing", message: "Parsing job description..." });

        const parseRes = await fetch(`${BASE_URL}/api/parse-jd`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ jdText }),
        });

        if (!parseRes.ok) throw new Error("Failed to parse JD");
        const { parsedJD }: { parsedJD: ParsedJD } = await parseRes.json();

        send({ step: "parsed", message: "JD parsed successfully", parsedJD });

        // Step 2: Match candidates
        send({ step: "matching", message: "Discovering and scoring candidates..." });

        const matchRes = await fetch(`${BASE_URL}/api/match-candidates`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ parsedJD }),
        });

        if (!matchRes.ok) throw new Error("Failed to match candidates");
        const { matchResults }: { matchResults: MatchResult[] } = await matchRes.json();

        send({ step: "matched", message: `Found ${matchResults.length} matching candidates`, matchResults });

        // Step 3: Simulate conversations for ALL matched candidates in parallel
        const names = matchResults
          .map((m) => MOCK_CANDIDATES.find((c) => c.id === m.candidateId)?.name.split(" ")[0])
          .filter(Boolean)
          .join(", ");

        send({
          step: "conversing",
          message: `Simulating outreach with all ${matchResults.length} candidates in parallel: ${names}...`,
          progress: 50,
        });

        const convPromises = matchResults.map(async (match) => {
          try {
            const convRes = await fetch(`${BASE_URL}/api/simulate-conversation`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                candidateId: match.candidateId,
                parsedJD,
                matchScore: match.matchScore,
              }),
            });
            if (!convRes.ok) return null;
            const { interestResult }: { interestResult: InterestResult } = await convRes.json();
            return interestResult;
          } catch {
            return null;
          }
        });

        const settled = await Promise.allSettled(convPromises);
        const interestResults: InterestResult[] = settled
          .map((r) => (r.status === "fulfilled" ? r.value : null))
          .filter((r): r is InterestResult => r !== null);

        send({
          step: "conversing",
          message: `Outreach complete — ${interestResults.length}/${matchResults.length} conversations simulated`,
          progress: 100,
        });

        // Step 4: Build ranked shortlist — Combined = 55% match + 45% interest
        const MATCH_WEIGHT = 0.55;
        const INTEREST_WEIGHT = 0.45;

        const rankedCandidates: RankedCandidate[] = matchResults
          .map((match) => {
            const candidate = MOCK_CANDIDATES.find((c) => c.id === match.candidateId)!;
            const interestResult = interestResults.find((r) => r.candidateId === match.candidateId);
            const interestScore = interestResult?.interestScore ?? 0;
            const combinedScore = Math.round(
              match.matchScore * MATCH_WEIGHT + interestScore * INTEREST_WEIGHT
            );

            return {
              candidate,
              matchScore: match.matchScore,
              interestScore,
              combinedScore,
              matchReasons: match.matchReasons,
              missingSkills: match.missingSkills,
              strengths: match.strengths,
              concerns: match.concerns,
              conversation: interestResult?.conversation ?? [],
              interestSignals: interestResult?.interestSignals ?? [],
              redFlags: interestResult?.redFlags ?? [],
              interestSummary: interestResult?.summary ?? "Not contacted",
            };
          })
          .sort((a, b) => b.combinedScore - a.combinedScore);

        const result: PipelineResult = {
          parsedJD,
          rankedCandidates,
          processedAt: new Date().toISOString(),
        };

        send({ step: "complete", message: "Pipeline complete!", result });
        controller.close();
      } catch (err) {
        send({ step: "error", message: String(err) });
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
    },
  });
}
